<?php


namespace Fkra\EgyptExpress\Logger;

class Logger extends \Monolog\Logger
{
}
